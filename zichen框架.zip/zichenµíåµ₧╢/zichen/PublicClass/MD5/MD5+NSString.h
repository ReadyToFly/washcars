//
//  MD5+NSString.h
//  meishihui
//
//  Created by u on 2017/4/8.
//  Copyright © 2017年 wql. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MD5_NSString : NSObject
+ (NSString *)MD5WithString:(NSString *)string;
@end
