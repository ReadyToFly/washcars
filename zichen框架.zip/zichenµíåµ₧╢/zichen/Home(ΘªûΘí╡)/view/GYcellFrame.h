//
//  GYcellFrame.h
//  zichen
//
//  Created by 连杰 on 2017/12/26.
//  Copyright © 2017年 郑超华. All rights reserved.
//

#import <Foundation/Foundation.h>
@class productModel;

@interface GYcellFrame : NSObject
@property (nonatomic,assign,readonly)CGRect leftImageViewF;
@property (nonatomic,assign,readonly)CGRect titleLableF;
@property (nonatomic,assign,readonly)CGRect detileLableF;
@property (nonatomic,assign,readonly)CGRect priceLableF;
@property (nonatomic,assign,readonly)CGRect buyLableF;
@property (nonatomic,assign,readonly)CGFloat cellHeight;


-(instancetype)initWithPModel:(productModel *)model;


@end
