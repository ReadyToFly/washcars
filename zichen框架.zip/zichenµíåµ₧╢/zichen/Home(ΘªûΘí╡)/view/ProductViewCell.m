//
//  ProductViewCell.m
//  zichen
//
//  Created by 连杰 on 2017/12/26.
//  Copyright © 2017年 郑超华. All rights reserved.
//

#import "ProductViewCell.h"

@implementation ProductViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}



-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        UIImageView *leftImag = [[UIImageView alloc]init];
        leftImag.backgroundColor = [UIColor redColor];
        [self.contentView addSubview:leftImag];
        _leftImageView = leftImag;
        
        UILabel *detileL = [[UILabel alloc]init];
        detileL.backgroundColor = [UIColor purpleColor];
        [self.contentView addSubview:detileL];
        _detileLable = detileL;
        
        UILabel *titleL = [[UILabel alloc]init];
        titleL.backgroundColor = [UIColor blackColor];
        [self.contentView addSubview:titleL];
        _detileLable = detileL;
        
        UILabel *priceL = [[UILabel alloc]init];
        priceL.backgroundColor = [UIColor yellowColor];
        [self.contentView addSubview:priceL];
        _priceLable = priceL;
        
        UILabel *buyL = [[UILabel alloc]init];
        buyL.backgroundColor = [UIColor orangeColor];
        [self.contentView addSubview:buyL];
        _buyLable = buyL;
        
        
    }
    return self;
}

-(void)layoutSubviews{
    self.leftImageView.frame = self.productMod.cellFrame.leftImageViewF;
    self.titleLable.frame = self.productMod.cellFrame.titleLableF;
    self.detileLable.frame = self.productMod.cellFrame.detileLableF;
    self.priceLable.frame = self.productMod.cellFrame.priceLableF;
    self.buyLable.frame = self.productMod.cellFrame.buyLableF;
    
}

-(void)setProductMod:(productModel *)productMod{
    _productMod = productMod;
    _buyLable.text = @"立即购买";
    _detileLable.text = @"套餐";
    
}



 

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
