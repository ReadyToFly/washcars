//
//  GYcellFrame.m
//  zichen
//
//  Created by 连杰 on 2017/12/26.
//  Copyright © 2017年 郑超华. All rights reserved.
//

#import "GYcellFrame.h"
#import "productModel.h"

@interface GYcellFrame()
@property (nonatomic,weak)productModel *productM;

@end
@implementation GYcellFrame

-(instancetype)initWithPModel:(productModel *)model{
    if (self = [super init]) {
        _productM = model;
    }
    return self;
}

-(CGFloat)cellHt{
    if (_cellHeight == 0) {
        //商品图片位置
        CGFloat margin = 10;
        CGFloat Dmargin = 20;
        _leftImageViewF = CGRectMake(margin, margin, 80, 60);
        
        //商品标题
        _titleLableF = CGRectMake(Dmargin +60,Dmargin, 100, 30);
        _detileLableF = CGRectMake(Dmargin +60, Dmargin +40, 100, 20);
        _priceLableF = CGRectMake(Dmargin +60, Dmargin +70, 100, 20);
        _buyLableF = CGRectMake(kScreenWidth - 40, 50, 60, 40);
        
        
    }
    return _cellHeight;
}



@end
