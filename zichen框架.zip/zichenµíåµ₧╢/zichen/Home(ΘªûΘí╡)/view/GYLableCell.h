



#import "GYNoticeViewCell.h"

@interface GYLableCell : GYNoticeViewCell

@property (nonatomic, strong) UILabel *customLab;

@end
