

//
//  Created by qm on 2017/12/13.
//  Copyright © 2017年 qm. All rights reserved.
//

#import "GYLableCell.h"

@interface GYLableCell ()

@property (nonatomic, strong) UIButton *leftBtn;



@end

@implementation GYLableCell

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithReuseIdentifier:reuseIdentifier];
    if (self) {
        [self setupUI];
    }
    return self;
}

// cell 高度30
- (void)setupUI
{
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
    [self.contentView addSubview:leftBtn];
    leftBtn.frame = CGRectMake(10, 5, 20, 20);
    
    _customLab = [[UILabel alloc]initWithFrame:CGRectMake(30+10, 5, kScreenWidth-60, 20)];
    _customLab.textColor = [UIColor redColor];
    _customLab.backgroundColor = [UIColor lightGrayColor];
    [self.contentView addSubview:_customLab];
}

@end
