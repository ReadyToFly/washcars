//
//  HomeViewController.m
//  zichen
//
//  Created by 郑超华 on 2017/12/25.
//  Copyright © 2017年 郑超华. All rights reserved.
//

#import "HomeViewController.h"
#import "Masonry.h"
#import "GYRollingNoticeView.h"
#import "GYNoticeViewCell.h"
#import "GYLableCell.h"
#import "ProductViewCell.h"


@interface HomeViewController ()<UIScrollViewDelegate,GYRollingNoticeViewDataSource, GYRollingNoticeViewDelegate,UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UIScrollView *headScroll;
@property (nonatomic,strong)UIPageControl *headPageControl;
@property (nonatomic,strong)MASConstraint *boottm;
@property (nonatomic,strong)GYRollingNoticeView *noticeView;
@property (nonatomic,strong)NSArray *arr1;
@property (nonatomic,strong)UITableView *tableView;

@end

@implementation HomeViewController
static NSString *ID = @"ViewController";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //添加头部轮播图
    [self setHeadScrollAndPageControl];
    //添加中不按钮
    [self setMiddleButton];
    //添加滚动公告栏
    [self setNoticeBoard];
    //添加等级产品
    [self addGradeProduct];
    
}

#pragma mark - ScrollAndPageConrol
-(void)setHeadScrollAndPageControl{
    _headScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 300)];
    _headScroll.backgroundColor = [UIColor yellowColor];
    //_headScroll.contentInsetAdjustmentBehavior = NO;
    
    /*
     * 暂时设置为三个
     */
    int HeadpageCount = 3;
    for (int i=0; i<=HeadpageCount; i++) {
        UIImage *image = [[UIImage alloc]init];
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth * i, 0, kScreenWidth, 300)];
        imageView.backgroundColor = [UIColor orangeColor];
        imageView.image = image;
        [_headScroll addSubview:imageView];
    }
    _headScroll.scrollEnabled = YES;
    _headScroll.bounces = NO;
    _headScroll.pagingEnabled = YES;
    _headScroll.showsHorizontalScrollIndicator = NO;
    _headScroll.showsVerticalScrollIndicator = NO;
    
    _headScroll.contentSize = CGSizeMake(kScreenWidth * HeadpageCount, 300);
    _headScroll.delegate = self;
    [self.view addSubview:_headScroll];
    
    _headPageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(kScreenWidth/HeadpageCount, _headScroll.frame.size.height -30, kScreenWidth/HeadpageCount, 20)];
    
    // 设置页数
    _headPageControl.numberOfPages = HeadpageCount;
    // 设置页码的点的颜色
    _headPageControl.pageIndicatorTintColor = [UIColor redColor];
    // 设置当前页码的点颜色
    _headPageControl.currentPageIndicatorTintColor = [UIColor purpleColor];
    [self.view addSubview:_headPageControl];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    // 计算当前在第几页
    _headPageControl.currentPage = (NSInteger)(scrollView.contentOffset.x / [UIScreen mainScreen].bounds.size.width);
}
    
#pragma mark - 中间平台按钮
-(void)setMiddleButton{
    
    NSArray *buttonTextA = [NSArray arrayWithObjects:@"平台简介",@"新手指南",@"系统公告",@"商城",nil];
    //NSArray *buttonImgA = [NSArray arrayWithObjects:@"平台简介",@"新手指南",@"系统公告",@"商城",nil];
    for (int i = 0; i <=3; i++) {
        UIView *btnView = [[UIView alloc]initWithFrame:CGRectMake(kScreenWidth /4*i, kScreenHeight -_headScroll.frame.size.height-64,kScreenWidth/4, 100)];
        
        UIButton *UpButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0,kScreenWidth/4, 70)];
        UpButton.backgroundColor = [UIColor purpleColor];
        
        
       UIButton *downButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 70,kScreenWidth/4, 30)];
        [downButton setTitle:[NSString stringWithFormat:@"%@",buttonTextA[i]] forState:UIControlStateNormal];
        [downButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        UpButton.tag = downButton.tag =i;
        [UpButton addTarget:self action:@selector(middleBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [downButton addTarget:self action:@selector(middleBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [btnView addSubview:UpButton];
        [btnView addSubview:downButton];
        [self.view addSubview:btnView];
    }
    
    
    
}
-(void)middleBtnClick:(UIButton *)btn{
    if (btn.tag == 0) {
        NSLog(@"0");
    }else if (btn.tag == 1){
    NSLog(@"1");
    }else if (btn.tag == 2){
        NSLog(@"2");
    }else if (btn.tag == 3){
        NSLog(@"3");
    }
}


#pragma mark - 轮播公告栏
-(void)setNoticeBoard{

    _arr1 = @[@"小米千元全面屏：抱歉，久等！625献上",
              @"可怜狗狗被抛弃，苦苦等候主人半年",
              @"三星中端新机改名，全面屏火力全开",
              @"学会这些，这5种花不用去花店买了",
              @"华为nova2S发布，剧透了荣耀V11？"
              ];
    

    [self creatRollingViewWithArray:_arr1 isFirst:NO];
    
    
}

// 请在合适的时机 停止
- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    //返回页面时候会停止
  // [_noticeView1 stopRoll];
}

- (void)creatRollingViewWithArray:(NSArray *)arr isFirst:(BOOL)isFirst
{
    
    GYRollingNoticeView *notView = [[GYRollingNoticeView alloc]initWithFrame:CGRectMake(0, 405, kScreenWidth,30)];
    notView.dataSource = self;
    notView.delegate = self;
    [self.view addSubview:notView];
    notView.backgroundColor = [UIColor lightGrayColor];
    
    _noticeView = notView;
    [notView registerClass:[GYNoticeViewCell class] forCellReuseIdentifier:@"GYNoticeViewCell"];
    [notView registerClass:[GYLableCell class] forCellReuseIdentifier:@"GYLableCell"];
    
    [notView reloadDataAndStartRoll];
}


- (NSInteger)numberOfRowsForRollingNoticeView:(GYRollingNoticeView *)rollingView
{
    
    if (rollingView == _noticeView) {
        return _arr1.count;
    }
    
    return 0;
}

- (__kindof GYNoticeViewCell *)rollingNoticeView:(GYRollingNoticeView *)rollingView cellAtIndex:(NSUInteger)index
{

    // label滚动显示文字
    if (rollingView == _noticeView) {
        
        GYLableCell *cell = [rollingView dequeueReusableCellWithIdentifier:@"GYLableCell"];
        cell.customLab.text = [NSString stringWithFormat:@"新版本2.0上线 %@", _arr1[index]];
        cell.contentView.backgroundColor = [UIColor purpleColor];
        return cell;
    
    }
    
    return nil;
}

- (void)didClickRollingNoticeView:(GYRollingNoticeView *)rollingView forIndex:(NSUInteger)index
{
    NSLog(@"点击的index: %ld", index);
}

#pragma mark - 等级产品
-(void)addGradeProduct{
    //产品上面图片
    UIImageView *tipImageV = [[UIImageView alloc]initWithFrame:CGRectMake(0,440,kScreenWidth, 50)];
    tipImageV.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:tipImageV];
    //tableView商品
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 500, kScreenWidth, 500) style:UITableViewStylePlain];
    _tableView.delegate = self;
   
    [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:ID];
    _tableView.backgroundColor = [UIColor blueColor];
    _tableView.estimatedRowHeight = 200;
    [self.view addSubview:_tableView];
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ProductViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    cell.productMod.leftImageView.backgroundColor = [UIColor redColor];
    cell.titleLable.text = @"套餐产品";
    cell.detileLable.text = @"套餐2";
    cell.buyLable.text = @"立即购买";
    cell.priceLable.text = @"$900";
    return cell;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
