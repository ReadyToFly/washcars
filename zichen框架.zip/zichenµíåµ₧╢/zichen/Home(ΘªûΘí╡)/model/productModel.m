//
//  productModel.m
//  zichen
//
//  Created by 连杰 on 2017/12/26.
//  Copyright © 2017年 郑超华. All rights reserved.
//

#import "productModel.h"

@implementation productModel


-(GYcellFrame *)cellF{
    if (_cellFrame == nil) {
        _cellFrame = [[GYcellFrame alloc] initWithPModel:self];
        
    }
    return _cellFrame;
}



@end
