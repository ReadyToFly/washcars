//
//  productModel.h
//  zichen
//
//  Created by 连杰 on 2017/12/26.
//  Copyright © 2017年 郑超华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GYcellFrame.h"

@interface productModel : NSObject
@property (nonatomic,strong,readonly)UIImageView *leftImageView;
@property (nonatomic,strong,readonly)UILabel *titleLable;
@property (nonatomic,strong,readonly)UILabel *detileLable;
@property (nonatomic,strong,readonly)UILabel *priceLable;
@property (nonatomic,strong,readonly)UILabel *buyLable;
@property (nonatomic,strong,readonly)GYcellFrame *cellFrame;


//-(instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end
