//
//  LBConst.h
//  meishihui
//
//  Created by 郑超华 on 2017/4/27.
//  Copyright © 2017年 郑超华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/********** Project Key ***********/

@interface LBConst : NSObject

// 登录接口
FOUNDATION_EXTERN NSString *const Loginkey;
// 获取待办菜单
FOUNDATION_EXTERN NSString *const CateOrderskey;

/********** 网络请求地址 ***********/

// 服务地址
FOUNDATION_EXTERN NSString *const kTestURLString;
FOUNDATION_EXTERN NSString *const kOnlineURLString;


@end
