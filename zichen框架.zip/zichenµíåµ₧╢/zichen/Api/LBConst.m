//
//  LBConst.m
//  meishihui
//
//  Created by 郑超华 on 2017/4/27.
//  Copyright © 2017年 郑超华. All rights reserved.
//

#import "LBConst.h"

/********** Project Key ***********/

// 登录接口
NSString *const Loginkey = @"erp/baseData/EmployeeLoginServlet?";


//////

/********** 网络请求地址 ***********/

// 服务地址
//测试服务器
NSString *const kTestURLString = @"http://rj.runjiaby.com/";
//线上服务器
NSString *const kOnlineURLString = @"http://rj.runjiaby.com/";








